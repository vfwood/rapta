package rapta;

import java.io.IOException;
import java.io.PrintWriter;
import java.security.Principal;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

import javax.security.auth.Subject;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import coho.auth.HttpUtils;
import weblogic.security.Security;
import weblogic.security.spi.WLSGroup;

/**
 * Responds to /user/detail with
 * 
 * { username: "<username>", roles { name: "role1", name: "role2" } }
 * 
 * @author vfwood
 * 
 */
public class UserDetailServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// Set response content type
		response.setContentType("text/html");

		HttpUtils.debug(request);

		// Actual logic goes here.
		PrintWriter out = response.getWriter();
		try {
			final String userDetails = getUserDetails(request);
			System.out.println("Response-Text");
			out.println(userDetails);
		} catch (final Exception e) {
			System.err.println("Error: " + e);
			e.printStackTrace();
			out.println("<pre>");
			e.printStackTrace(out);
			out.println("</pre>");
			out.println("Error doing subject stuff: " + e);
		}
	}

	@Override
	protected void doPost(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException {
		doGet(arg0, arg1);
	}

	

	protected String getUserDetails(HttpServletRequest request) {

		Subject subject = Security.getCurrentSubject();
		List<String> groupNames = new ArrayList<String>();

		String groups = "{";
		String sep = "";
		for (Principal p : subject.getPrincipals()) {
			if (p instanceof WLSGroup) {
				groupNames.add(p.getName());
				groups = groups + sep + "name:" + '"' + p.getName() + '"';
				sep = ",\n";
			}
		}

		groups += "}";

		String username = (request.getUserPrincipal() != null ? request.getUserPrincipal().getName()
				: "<no-user-principal>");
		String output = "{ version: \"1.6\", username: " + '"' + username + '"' + ",\n roles: " + groups;

		output += ", request_authtype: \"" + request.getAuthType() + "\"";
		
		Enumeration<String> headerNames = request.getHeaderNames();
		while (headerNames.hasMoreElements()) {
			String headerName = headerNames.nextElement();
			Enumeration<String> headers = request.getHeaders(headerName);
			while (headers.hasMoreElements()) {
				String headerValue = headers.nextElement();
				output += ", header_" + headerName + ": \"" + headerValue + "\"";
			}
        }
		

		output += ", request_URI: \"" + request.getRequestURI() + "\"";
		output += ", request_UserPrincipal: \"" + request.getUserPrincipal() + "\"";

		output += "}";
		return output;

	}

}
