package coho.proxy;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import coho.auth.Authentication;
import coho.auth.HttpUtils;
import coho.proxy.data.FileStore;

public class DocumentRetrievalServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse resp)
			throws ServletException, IOException {
		
		System.out.println("\n\n\n-----Get Properties Start-----");

		final String userDN = Authentication.getloggedInUserDN(request);
		request.setAttribute("userDN", userDN);

		final String userID = Authentication.getUserID(request);
		request.setAttribute("userID", userID);


		// Get what comes after /document/get/
		final String id = request.getParameter("url");
		
		System.out.println("Requesting from WLS2: " + id);
		String doc = null;
		try {
			HttpUtils.debug(request);
			doc = FileStore.getById(request, id);
		} catch (Exception e) {
			doc = "Error: " + e.getMessage();
		}
		request.setAttribute("doc", doc);


		String nextJSP = "/documentGet.jsp";
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(nextJSP);
		dispatcher.forward(request, resp);
		System.out.println("-----Get Properties End-----\n\n\n");
	}
}
