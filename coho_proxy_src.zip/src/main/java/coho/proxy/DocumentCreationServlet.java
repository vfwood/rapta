package coho.proxy;

import java.io.IOException;
import java.util.Arrays;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import coho.auth.Authentication;
import coho.proxy.data.FileStore;

public class DocumentCreationServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	public void doPost(final HttpServletRequest request, final HttpServletResponse resp) throws ServletException,
			IOException {

		
		System.out.println("Create: Document Creation");
		
		final String userDN = Authentication.getloggedInUserDN(request);
		request.setAttribute("userDN", userDN);

		final String userID = Authentication.getUserID(request);
		request.setAttribute("userID", userID);

		// Get what comes after /document/get/
		final String url = request.getRequestURI();
		String[] split = url.split("/");
		System.out.println("Have " + split.length + " parts" + Arrays.asList(split));
		if (split.length != 5) {
			throw new IOException("Unexpected number of params - " + split.length);
		}
		final String id = split[4];

		// Now get the contents as POST param
		final String contents = request.getParameter("contents");

		String doc = null;
		try {
			FileStore.store(request, id, contents);
			doc = FileStore.getById(request, id);
		} catch (Exception e) {
			doc = "Error: " + e.getMessage();
		}
		request.setAttribute("doc", doc);
		
		String nextJSP = "/documentGet.jsp";
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(nextJSP);
		dispatcher.forward(request, resp);

	}
}
