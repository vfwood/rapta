package coho.proxy.data;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import coho.auth.HttpUtils;
import coho.auth.RequestContext;

public class FileStore {

	public synchronized static String updateDocumentProperties(HttpServletRequest request, final String userDN)
			throws Exception {

		// Service URL
		final String service2RelativeUrl = "https://cohowl2.cohowinery.com:7002/coho/document/listItemAllFields";

		// Parameters...
		final Map<String, String> parameters = new java.util.HashMap<>();
		final String data = request.getParameter("data");
		parameters.put("data", data);

		// Get the endpoint parameter and pass it on:
		final String endpoint = request.getParameter("url");
		parameters.put("url", endpoint);

		return HttpUtils.doHttpPost(service2RelativeUrl, new RequestContext(request),
				HttpUtils.asNameValuePair(parameters), new HashMap<String, String>());
	}

	public synchronized static String getById(final HttpServletRequest request, final String id) throws Exception {
		final String url = "https://cohowl2.cohowinery.com:7002/coho/document/getFileByServerRelativeUrl";
		System.out.println("Doing post passing [" + id + "]");
		return HttpUtils.doHttpPost(url, new RequestContext(request), HttpUtils.asNameValuePair("url", id),
				new HashMap<String, String>());
	}

	public synchronized static String store(final HttpServletRequest request, final String id, final String contents)
			throws Exception {

		final String url = "https://cohowl2.cohowinery.com:7002/coho/document/add/" + id;
		final String result = HttpUtils.doHttpPost(url, new RequestContext(request),
				HttpUtils.asNameValuePair("contents", "test2"), new HashMap<String, String>());
		return result;
	}
}
