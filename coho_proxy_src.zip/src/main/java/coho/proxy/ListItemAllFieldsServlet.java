package coho.proxy;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import coho.auth.Authentication;
import coho.proxy.data.FileStore;

public class ListItemAllFieldsServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse resp) throws ServletException, IOException {
		
		final String userDN = Authentication.getloggedInUserDN(request);
		request.setAttribute("userDN", userDN);

		final String userID = Authentication.getUserID(request);
		request.setAttribute("userID", userID);

		try {
			// We have to post this data to Service 2.
			final String service2Response = FileStore.updateDocumentProperties(request, userDN);
			request.setAttribute("response", service2Response);
		} catch (Exception e) {
			request.setAttribute("response", e.getMessage());
		}
		String nextJSP = "/listItemAllFields.jsp";
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(nextJSP);
		dispatcher.forward(request, resp);
	}
}
